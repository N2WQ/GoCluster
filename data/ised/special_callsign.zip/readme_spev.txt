Each record has the following data, separated by ";"

Special Call Sign
First Date of Event (YYYY-MM-DD)
Last Date of Event (YYYY-MM-DD)
Event Name (English)
Event Name (French)
Trustee Call Sign
Special Call Sign Used By
